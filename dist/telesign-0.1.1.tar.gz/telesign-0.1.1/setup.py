from setuptools import setup

setup(
    name='telesign',
    description='A simple microservice to maintain a collection of words.',
    version='0.1.1',
    author='VS',
    packages=['telesign']
)


